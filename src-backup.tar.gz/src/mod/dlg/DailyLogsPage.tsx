import { useState, useMemo } from 'react';
import { useDlg, type DailyLog, type Death, type Vaccine, type Medication, type Activity, VENTILATION_LABEL, LITTER_LABEL, BEHAVIOR_LABEL, DISTRIBUTION_LABEL, SOUND_LABEL, DEATH_CAUSES, causeLabel, tempWarning, humidityWarning, waterFeedRatio, mortalityRate } from './store';
import { useFlk, getAgeDays } from '../flk/store';
import { useBrd } from '../brd/store';
import { Btn, BtnRow, Empty, Field, Grid2, Grid3, Input, Modal, PageContainer, Select, Tag } from '../../shr/components/ui';
import ExpandableCard from '../../shr/components/ExpandableCard';
import DatePicker from '../../shr/components/DatePicker';
import TimePicker from '../../shr/components/TimePicker';
import { toFa, toEn } from '../../shr/utils/fa';

interface F {
  id?: string;
  flockId: string; date: string; entryTime: string;
  temperature: string; humidity: string; ventilation: string; litter: string;
  behavior: string; distribution: string; appearance: string; sound: string;
  feedType: string; feedAmount: string; feedRemaining: string; waterAmount: string;
  deaths: Death[];
  vaccines: Vaccine[]; medications: Medication[]; activities: Activity[];
  notes: string;
}

const newLog = (flockId = ''): F => ({
  flockId, date: '', entryTime: '',
  temperature:'', humidity:'', ventilation:'ok', litter:'dry',
  behavior:'active', distribution:'uniform', appearance:'', sound:'normal',
  feedType:'', feedAmount:'', feedRemaining:'', waterAmount:'',
  deaths: [], vaccines: [], medications: [], activities: [],
  notes: ''
});

type TabId = 'today' | 'history';

export default function DailyLogsPage() {
  const { logs, add, update, remove } = useDlg();
  const { flocks } = useFlk();
  const { birds, breeds } = useBrd();

  const [tab, setTab] = useState<TabId>('today');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<F>(newLog());
  const [err, setErr] = useState('');
  const [delId, setDelId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [expandedLists, setExpandedLists] = useState<Record<string, boolean>>({});

  const activeFlocks = flocks.filter(f => f.status === 'active');
  const today = new Date();
  const todayStr = `${today.getFullYear()}/${String(today.getMonth()+1).padStart(2,'0')}/${String(today.getDate()).padStart(2,'0')}`;

  const todaysLogs = useMemo(() => logs.filter(l => l.date === todayStr), [logs, todayStr]);
  const historicalLogs = useMemo(() => logs.filter(l => l.date !== todayStr).sort((a, b) => b.date.localeCompare(a.date)), [logs, todayStr]);

  const openNew = () => {
    if (activeFlocks.length === 0) { alert('اول یک گله بسازید'); return; }
    setForm({ ...newLog(activeFlocks[0].id), date: todayStr });
    setErr(''); setOpen(true);
  };
  const openEdit = (l: DailyLog) => {
    setForm({
      id: l.id, flockId: l.flockId, date: l.date, entryTime: l.entryTime,
      temperature: l.temperature ? toFa(l.temperature) : '',
      humidity: l.humidity ? toFa(l.humidity) : '',
      ventilation: l.ventilation,
      litter: l.litter,
      behavior: l.behavior, distribution: l.distribution,
      appearance: l.appearance, sound: l.sound,
      feedType: l.feedType, feedAmount: l.feedAmount ? toFa(l.feedAmount) : '',
      feedRemaining: l.feedRemaining ? toFa(l.feedRemaining) : '',
      waterAmount: l.waterAmount ? toFa(l.waterAmount) : '',
      deaths: l.deaths || [], vaccines: l.vaccines || [],
      medications: l.medications || [], activities: l.activities || [],
      notes: l.notes
    });
    setErr(''); setOpen(true);
  };

  const selectedFlock = activeFlocks.find(f => f.id === form.flockId);
  const flockAliveCount = selectedFlock?.currentCount || selectedFlock?.initialCount || 0;
  const num = (s: string) => s ? parseFloat(toEn(s).replace('٫','.')) || null : null;
  const int = (s: string) => s ? parseInt(toEn(s)) || null : null;

  const save = () => {
    if (!form.flockId) { setErr('گله اجباری است'); return; }
    if (!form.date.trim()) { setErr('تاریخ اجباری است'); return; }
    const dCount = form.deaths.reduce((a, x) => a + (x.count || 0), 0);
    if (flockAliveCount && dCount > flockAliveCount) {
      setErr(`مجموع تلفات (${toFa(dCount)}) از تعداد زنده گله (${toFa(flockAliveCount)}) بیشتر است`);
      return;
    }
    const data: Omit<DailyLog, 'id'> = {
      flockId: form.flockId, date: form.date, entryTime: form.entryTime,
      temperature: num(form.temperature), humidity: num(form.humidity),
      ventilation: form.ventilation, litter: form.litter,
      behavior: form.behavior, distribution: form.distribution,
      appearance: form.appearance.trim(), sound: form.sound,
      feedType: form.feedType.trim(), feedAmount: num(form.feedAmount),
      feedRemaining: num(form.feedRemaining), waterAmount: num(form.waterAmount),
      deathsCount: dCount, deaths: form.deaths,
      vaccines: form.vaccines, medications: form.medications,
      activities: form.activities, notes: form.notes.trim()
    };
    if (form.id) update(form.id, data); else add(data);
    setOpen(false);
  };

  const toggleList = (id: string, key: string) => {
    const k = id + ':' + key;
    setExpandedLists(p => ({ ...p, [k]: !p[k] }));
  };

  const deleteTarget = delId ? logs.find(l => l.id === delId) : null;

  const tabs: { id: TabId; label: string }[] = [
    { id: 'today', label: 'امروز' },
    { id: 'history', label: 'تاریخچه' }
  ];

  const renderLogCard = (l: DailyLog, i: number) => {
    const flock = flocks.find(f => f.id === l.flockId);
    const bird = flock ? birds.find(b => b.id === flock.birdId) : null;
    const breed = flock ? breeds.find(b => b.id === flock.breedId) : null;
    const isOpen = expandedId === l.id;
    const tWarn = tempWarning(l.temperature);
    const hWarn = humidityWarning(l.humidity);
    const hasProblem = tWarn !== 'ok' || hWarn !== 'ok' || l.deathsCount > 0;
    const accent: any = hasProblem ? (tWarn === 'danger' || hWarn === 'danger' ? 'warn' : 'warn') : 'accent';

    return (
      <ExpandableCard key={l.id} accent={accent} index={toFa(i + 1)} iconEmoji="📋"
        title={flock?.name || '—'}
        subtitle={`${toFa(l.date)}${l.entryTime ? ` · ساعت ${toFa(l.entryTime)}` : ''}${bird ? ` · ${bird.name}` : ''}${breed ? ` (${breed.name})` : ''}`}
        isOpen={isOpen} onToggle={() => setExpandedId(isOpen ? null : l.id)}
        badge={l.deathsCount > 0 ? <Tag tone="amber">{toFa(l.deathsCount)} تلفات</Tag> : undefined}
        summary={<>
          {l.temperature && <span style={{ color: tWarn === 'danger' ? 'var(--danger)' : tWarn === 'warn' ? 'var(--warn)' : undefined }}>
            🌡 {toFa(l.temperature)}°
          </span>}
          {l.humidity && <span style={{ color: hWarn === 'danger' ? 'var(--danger)' : hWarn === 'warn' ? 'var(--warn)' : undefined }}>
            💧 {toFa(l.humidity)}٪
          </span>}
          {l.feedAmount && <span>🌾 {toFa(l.feedAmount)} kg</span>}
          {l.waterAmount && <span>💧 {toFa(l.waterAmount)} L</span>}
        </>}
      >
        {/* هشدارها */}
        {(tWarn !== 'ok' || hWarn !== 'ok') && (
          <div style={{
            padding: '8px 12px',
            background: 'var(--warn-soft)',
            border: '1px dashed var(--warn)',
            borderRadius: 'var(--r-md)',
            fontSize: 'var(--fs-xs)',
            color: 'var(--warn)',
            fontWeight: 700
          }}>
            ⚠ {tWarn !== 'ok' ? `دما ${tWarn === 'danger' ? 'خطرناک' : 'نامناسب'}` : ''}
            {tWarn !== 'ok' && hWarn !== 'ok' ? ' · ' : ''}
            {hWarn !== 'ok' ? `رطوبت ${hWarn === 'danger' ? 'خطرناک' : 'نامناسب'}` : ''}
          </div>
        )}

        <Section title="🌡 محیط">
          <Grid2>
            {l.temperature !== null && <Row l="دما" v={`${toFa(l.temperature)} °C`} warn={tWarn !== 'ok'} />}
            {l.humidity !== null && <Row l="رطوبت" v={`${toFa(l.humidity)} ٪`} warn={hWarn !== 'ok'} />}
          </Grid2>
          <Grid2>
            <Row l="تهویه" v={VENTILATION_LABEL[l.ventilation] || '—'} />
            <Row l="بستر" v={LITTER_LABEL[l.litter] || '—'} />
          </Grid2>
        </Section>

        <Section title="🐔 مشاهده پرنده">
          <Grid3>
            <Row l="رفتار" v={BEHAVIOR_LABEL[l.behavior] || '—'} />
            <Row l="توزیع" v={DISTRIBUTION_LABEL[l.distribution] || '—'} />
            <Row l="صدا" v={SOUND_LABEL[l.sound] || '—'} />
          </Grid3>
          {l.appearance && <div style={{ fontSize: 'var(--fs-sm)', padding: '8px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)', lineHeight: 1.7 }}>{l.appearance}</div>}
        </Section>

        {(l.feedAmount !== null || l.waterAmount !== null) && (
          <Section title="🌾 تغذیه و آب">
            <Grid2>
              {l.feedType && <Row l="نوع جیره" v={l.feedType} />}
              {l.feedAmount !== null && <Row l="دان" v={`${toFa(l.feedAmount)} kg`} />}
            </Grid2>
            <Grid2>
              {l.feedRemaining !== null && <Row l="باقیمانده" v={`${toFa(l.feedRemaining)} kg`} />}
              {l.waterAmount !== null && <Row l="آب" v={`${toFa(l.waterAmount)} L`} />}
            </Grid2>
            {l.waterAmount && l.feedAmount && (
              <Row l="نسبت آب/دان" v={`${toFa((l.waterAmount / l.feedAmount).toFixed(1))}`} />
            )}
          </Section>
        )}

        {(l.deaths && l.deaths.length > 0) && (
          <Section title="💀 تلفات">
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-sm)', padding: '8px 10px', background: 'var(--danger-soft)', color: 'var(--danger)', borderRadius: 'var(--r-sm)', fontWeight: 700 }}>
              <span>مجموع تلفات امروز:</span>
              <span>{toFa(l.deaths.reduce((a, x) => a + (x.count || 0), 0))} پرنده</span>
            </div>
            {l.deaths.map(d => (
              <div key={d.id} style={{ fontSize: 'var(--fs-sm)', padding: '8px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)', display: 'flex', flexDirection: 'column', gap: 3 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text)' }}><b>{toFa(d.count)}</b> پرنده</span>
                  <span style={{ color: 'var(--warn)', fontSize: 'var(--fs-xs)', fontWeight: 600 }}>{causeLabel(d.cause)}</span>
                </div>
                {d.notes && <span style={{ color: 'var(--muted)', fontSize: 'var(--fs-xs)' }}>{d.notes}</span>}
              </div>
            ))}
          </Section>
        )}

        {l.vaccines.length > 0 && (
          <Section title="💉 واکسن">
            {l.vaccines.map(v => (
              <div key={v.id} style={{ fontSize: 'var(--fs-sm)', padding: '8px 10px', background: 'var(--accent-soft)', borderRadius: 'var(--r-sm)', color: 'var(--accent)' }}>
                <b>{v.name}</b>{v.dose ? ` — دوز ${v.dose}` : ''}{v.method ? ` · ${v.method}` : ''}
              </div>
            ))}
          </Section>
        )}

        {l.medications.length > 0 && (
          <Section title="💊 دارو">
            {l.medications.map(m => (
              <div key={m.id} style={{ fontSize: 'var(--fs-sm)', padding: '8px 10px', background: 'var(--info-soft)', borderRadius: 'var(--r-sm)', color: 'var(--info)' }}>
                <b>{m.name}</b>{m.dose ? ` — ${m.dose}` : ''}{m.withdrawalDays ? ` · منع مصرف ${toFa(m.withdrawalDays)} روز` : ''}
              </div>
            ))}
          </Section>
        )}

        {l.activities.length > 0 && (
          <Section title="🔧 فعالیت‌ها">
            {l.activities.map(a => (
              <div key={a.id} style={{ fontSize: 'var(--fs-sm)', padding: '6px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)' }}>
                <b>{a.type}</b>{a.notes ? ` — ${a.notes}` : ''}
              </div>
            ))}
          </Section>
        )}

        {l.notes && (
          <Section title="📝 یادداشت">
            <div style={{ fontSize: 'var(--fs-sm)', lineHeight: 1.7, padding: '8px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)' }}>{l.notes}</div>
          </Section>
        )}

        <div style={{ display: 'flex', gap: 6, paddingTop: 4 }}>
          <Btn size="sm" onClick={() => openEdit(l)} style={{ flex: 1 }}>ویرایش</Btn>
          <Btn size="sm" onClick={() => setDelId(l.id)} style={{ flex: 1 }}>حذف</Btn>
        </div>
      </ExpandableCard>
    );
  };

  const currentList = tab === 'today' ? todaysLogs : historicalLogs;

  return (
    <div>
      <div style={{
        display: 'flex', gap: 0, borderBottom: '1px solid var(--border)',
        padding: '0 12px', background: 'var(--header-bg)',
        position: 'sticky', top: 52, zIndex: 11
      }}>
        {tabs.map(t => (
          <div key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '11px 14px', fontSize: 'var(--fs-base)', fontWeight: 600,
            color: tab === t.id ? 'var(--accent)' : 'var(--muted)',
            cursor: 'pointer', position: 'relative',
            display: 'flex', alignItems: 'center', gap: 5
          }}>
            {t.label}
            <span style={{
              fontSize: 10,
              background: tab === t.id ? 'var(--accent-soft)' : 'var(--input-bg)',
              color: tab === t.id ? 'var(--accent)' : 'var(--muted)',
              padding: '1px 5px', borderRadius: 8, fontWeight: 700
            }}>
              {toFa(t.id === 'today' ? todaysLogs.length : logs.length - todaysLogs.length)}
            </span>
            {tab === t.id && <div style={{ position: 'absolute', bottom: 0, right: 14, left: 14, height: 2.5, background: 'var(--accent)', borderRadius: '3px 3px 0 0' }} />}
          </div>
        ))}
      </div>

      <PageContainer>
        {currentList.length === 0 ? (
          <Empty
            icon={<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>}
            title={tab === 'today' ? 'امروز ثبتی ندارید' : 'تاریخچه خالی است'}
            desc={tab === 'today' ? 'اولین ثبت امروز را انجام دهید — محیط، تغذیه، تلفات.' : 'پس از ثبت اولین روز، اینجا نمایش داده می‌شود.'}
            action={<Btn variant="primary" onClick={openNew}>+ ثبت امروز</Btn>}
          />
        ) : (
          <>
            {currentList.map((l, i) => renderLogCard(l, i))}
            <Btn variant="primary" full onClick={openNew}>+ ثبت روز جدید</Btn>
          </>
        )}

        {/* ============ Modal Form ============ */}
        <Modal open={open} onClose={() => setOpen(false)} title={form.id ? 'ویرایش ثبت روزانه' : 'ثبت روزانه جدید'}
          footer={<BtnRow><Btn variant="primary" onClick={save}>ذخیره</Btn><Btn onClick={() => setOpen(false)}>لغو</Btn></BtnRow>}>

          <Grid2>
            <Field label="گله" required>
              <Select value={form.flockId} onChange={e => setForm({ ...form, flockId: e.target.value })}>
                {activeFlocks.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
              </Select>
            </Field>
            <Field label="ساعت ورود">
              <TimePicker value={form.entryTime} onChange={v => setForm({ ...form, entryTime: v })} placeholder="انتخاب ساعت" />
            </Field>
          </Grid2>

          <Field label="تاریخ" required>
            <DatePicker value={form.date} onChange={v => setForm({ ...form, date: v })} />
          </Field>

          {flockAliveCount > 0 && (
            <div style={{ padding: '8px 12px', background: 'var(--info-soft)', border: '1px solid var(--info)', borderRadius: 'var(--r-md)', fontSize: 'var(--fs-xs)', color: 'var(--info)', fontWeight: 600, textAlign: 'center' }}>
              تعداد زنده گله: {toFa(flockAliveCount)} پرنده
            </div>
          )}

          <SectionTitle>🌡 شرایط محیطی</SectionTitle>

          <Grid2>
            <Field label="دما" hint="۱۵ تا ۳۰ درجه">
              <Input placeholder="۲۲" inputMode="decimal" dir="ltr" value={form.temperature} onChange={e => setForm({ ...form, temperature: e.target.value })} unit="°C" />
            </Field>
            <Field label="رطوبت" hint="۳۰ تا ۸۰ درصد">
              <Input placeholder="۶۰" inputMode="numeric" dir="ltr" value={form.humidity} onChange={e => setForm({ ...form, humidity: e.target.value })} unit="٪" max={100} min={0} />
            </Field>
          </Grid2>

          <Grid2>
            <Field label="تهویه">
              <Select value={form.ventilation} onChange={e => setForm({ ...form, ventilation: e.target.value })}>
                <option value="ok">مناسب</option>
                <option value="low">ضعیف</option>
                <option value="high">شدید</option>
              </Select>
            </Field>
            <Field label="بستر">
              <Select value={form.litter} onChange={e => setForm({ ...form, litter: e.target.value })}>
                <option value="dry">خشک</option>
                <option value="wet">مرطوب</option>
                <option value="clumped">کلوخه</option>
              </Select>
            </Field>
          </Grid2>

          <SectionTitle>🐔 مشاهده پرنده</SectionTitle>

          <Grid3>
            <Field label="رفتار">
              <Select value={form.behavior} onChange={e => setForm({ ...form, behavior: e.target.value })}>
                <option value="active">فعال</option>
                <option value="lethargic">بی‌حال</option>
                <option value="excited">پرهیجان</option>
              </Select>
            </Field>
            <Field label="توزیع">
              <Select value={form.distribution} onChange={e => setForm({ ...form, distribution: e.target.value })}>
                <option value="uniform">یکنواخت</option>
                <option value="cornered">گوشه‌گیر</option>
              </Select>
            </Field>
            <Field label="صدا">
              <Select value={form.sound} onChange={e => setForm({ ...form, sound: e.target.value })}>
                <option value="normal">طبیعی</option>
                <option value="cough">سرفه</option>
                <option value="sneeze">عطسه</option>
              </Select>
            </Field>
          </Grid3>

          <Field label="ظاهر عمومی">
            <Input placeholder="رنگ پر، چشم، تاج، منقار..." value={form.appearance} onChange={e => setForm({ ...form, appearance: e.target.value })} />
          </Field>

          <SectionTitle>🌾 تغذیه و آب</SectionTitle>

          <Grid2>
            <Field label="نوع جیره">
              <Input placeholder="استارتر، گروور..." value={form.feedType} onChange={e => setForm({ ...form, feedType: e.target.value })} />
            </Field>
            <Field label="مقدار دان">
              <Input placeholder="۵۰" inputMode="decimal" dir="ltr" value={form.feedAmount} onChange={e => setForm({ ...form, feedAmount: e.target.value })} unit="kg" />
            </Field>
          </Grid2>

          <Grid2>
            <Field label="دان باقیمانده">
              <Input placeholder="۰" inputMode="decimal" dir="ltr" value={form.feedRemaining} onChange={e => setForm({ ...form, feedRemaining: e.target.value })} unit="kg" />
            </Field>
            <Field label="مقدار آب">
              <Input placeholder="۱۰۰" inputMode="decimal" dir="ltr" value={form.waterAmount} onChange={e => setForm({ ...form, waterAmount: e.target.value })} unit="L" />
            </Field>
          </Grid2>

          <SectionTitle>💀 تلفات</SectionTitle>

          {/* شمارنده‌ی کل */}
          {form.deaths.length > 0 && (
            <div style={{
              padding: '8px 12px',
              background: 'var(--danger-soft)',
              border: '1px solid var(--danger)',
              borderRadius: 'var(--r-md)',
              fontSize: 'var(--fs-sm)',
              color: 'var(--danger)',
              fontWeight: 700,
              textAlign: 'center'
            }}>
              مجموع: {toFa(form.deaths.reduce((a, x) => a + (x.count || 0), 0))} پرنده
              {flockAliveCount ? ` از ${toFa(flockAliveCount)}` : ''}
            </div>
          )}

          {/* لیست تلفات */}
          {form.deaths.map((d, i) => (
            <div key={d.id} style={{
              padding: '10px 12px',
              background: 'var(--danger-soft)',
              border: '1px solid var(--danger)',
              borderRadius: 'var(--r-md)',
              display: 'flex', flexDirection: 'column', gap: 8
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--danger)', fontWeight: 700 }}>
                  رکورد {toFa(i + 1)}
                </span>
                <button
                  type="button"
                  onClick={() => setForm(f => ({ ...f, deaths: f.deaths.filter(x => x.id !== d.id) }))}
                  style={{
                    background: 'none', border: 'none',
                    color: 'var(--danger)', cursor: 'pointer',
                    fontFamily: 'inherit', fontSize: 14
                  }}
                >✕</button>
              </div>
              <Grid2>
                <Field label="تعداد">
                  <Input
                    placeholder="۰"
                    inputMode="numeric"
                    dir="ltr"
                    value={String(d.count || '')}
                    onChange={e => setForm(f => ({
                      ...f,
                      deaths: f.deaths.map(x => x.id === d.id ? { ...x, count: parseInt(toEn(e.target.value)) || 0 } : x)
                    }))}
                    min={0}
                    max={flockAliveCount || undefined}
                  />
                </Field>
                <Field label="علت">
                  <Select
                    value={d.cause || ''}
                    onChange={e => setForm(f => ({
                      ...f,
                      deaths: f.deaths.map(x => x.id === d.id ? { ...x, cause: e.target.value } : x)
                    }))}
                  >
                    {DEATH_CAUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </Select>
                </Field>
              </Grid2>
              <Field label="توضیحات">
                <Input
                  placeholder="جزئیات علت، محل، زمان..."
                  value={d.notes || ''}
                  onChange={e => setForm(f => ({
                    ...f,
                    deaths: f.deaths.map(x => x.id === d.id ? { ...x, notes: e.target.value } : x)
                  }))}
                />
              </Field>
            </div>
          ))}

          <Btn
            size="sm"
            full
            onClick={() => setForm(f => ({
              ...f,
              deaths: [...f.deaths, { id: crypto.randomUUID(), count: 0, cause: '', notes: '' }]
            }))}
          >
            + افزودن رکورد تلفات
          </Btn>

          <SectionTitle>💉 واکسن و دارو</SectionTitle>

          <Btn size="sm" onClick={() => setForm(f => ({ ...f, vaccines: [...f.vaccines, { id: crypto.randomUUID(), name:'', dose:'', method:'', reaction:'' }] }))} full>
            + افزودن واکسن
          </Btn>
          {form.vaccines.map((v, i) => (
            <div key={v.id} style={{ padding: '10px 12px', background: 'var(--accent-soft)', border: '1px solid var(--accent-border)', borderRadius: 'var(--r-md)', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--accent)', fontWeight: 700 }}>واکسن {toFa(i+1)}</span>
                <button onClick={() => setForm(f => ({ ...f, vaccines: f.vaccines.filter(x => x.id !== v.id) }))} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontFamily: 'inherit' }}>✕</button>
              </div>
              <Grid2>
                <Input placeholder="نام" value={v.name} onChange={e => setForm(f => ({ ...f, vaccines: f.vaccines.map(x => x.id === v.id ? { ...x, name: e.target.value } : x) }))} />
                <Input placeholder="دوز" value={v.dose} onChange={e => setForm(f => ({ ...f, vaccines: f.vaccines.map(x => x.id === v.id ? { ...x, dose: e.target.value } : x) }))} />
              </Grid2>
            </div>
          ))}

          <Btn size="sm" onClick={() => setForm(f => ({ ...f, medications: [...f.medications, { id: crypto.randomUUID(), name:'', dose:'', method:'', withdrawalDays: null }] }))} full>
            + افزودن دارو
          </Btn>
          {form.medications.map((m, i) => (
            <div key={m.id} style={{ padding: '10px 12px', background: 'var(--info-soft)', border: '1px solid var(--info)', borderRadius: 'var(--r-md)', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--info)', fontWeight: 700 }}>دارو {toFa(i+1)}</span>
                <button onClick={() => setForm(f => ({ ...f, medications: f.medications.filter(x => x.id !== m.id) }))} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontFamily: 'inherit' }}>✕</button>
              </div>
              <Grid2>
                <Input placeholder="نام" value={m.name} onChange={e => setForm(f => ({ ...f, medications: f.medications.map(x => x.id === m.id ? { ...x, name: e.target.value } : x) }))} />
                <Input placeholder="دوز" value={m.dose} onChange={e => setForm(f => ({ ...f, medications: f.medications.map(x => x.id === m.id ? { ...x, dose: e.target.value } : x) }))} />
              </Grid2>
            </div>
          ))}

          <SectionTitle>🔧 فعالیت‌ها</SectionTitle>

          <Btn size="sm" onClick={() => setForm(f => ({ ...f, activities: [...f.activities, { id: crypto.randomUUID(), type:'', notes:'' }] }))} full>
            + افزودن فعالیت
          </Btn>
          {form.activities.map((a, i) => (
            <div key={a.id} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <Input placeholder="نوع فعالیت (ضدعفونی، تعمیر...)" value={a.type} onChange={e => setForm(f => ({ ...f, activities: f.activities.map(x => x.id === a.id ? { ...x, type: e.target.value } : x) }))} />
              <button onClick={() => setForm(f => ({ ...f, activities: f.activities.filter(x => x.id !== a.id) }))} style={{ background: 'none', border: '1px solid var(--border)', borderRadius: 'var(--r-md)', color: 'var(--danger)', cursor: 'pointer', fontFamily: 'inherit', width: 38, height: 38, flexShrink: 0 }}>✕</button>
            </div>
          ))}

          <SectionTitle>📝 یادداشت</SectionTitle>
          <Field label="یادداشت">
            <Input placeholder="..." value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} />
          </Field>

          {err && <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--danger)' }}>✕ {err}</div>}
        </Modal>

        <Modal open={!!delId} onClose={() => setDelId(null)} title="حذف ثبت روزانه"
          footer={<BtnRow><Btn variant="danger" onClick={() => { if (delId) remove(delId); setDelId(null); }}>حذف کن</Btn><Btn onClick={() => setDelId(null)}>لغو</Btn></BtnRow>}>
          <div style={{ textAlign: 'center', fontSize: 'var(--fs-md)' }}>
            حذف این ثبت؟
          </div>
        </Modal>
      </PageContainer>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <>
      <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)', fontWeight: 700, letterSpacing: '.3px' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>{children}</div>
    </>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      paddingTop: 10, marginTop: 4,
      borderTop: '1px dashed var(--border)',
      fontSize: 'var(--fs-sm)', fontWeight: 700, color: 'var(--muted)'
    }}>{children}</div>
  );
}

function Row({ l, v, warn }: { l: string; v: string; warn?: boolean }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-sm)',
      padding: '6px 10px',
      background: warn ? 'var(--warn-soft)' : 'var(--input-bg)',
      borderRadius: 'var(--r-sm)',
      color: warn ? 'var(--warn)' : undefined,
      fontWeight: warn ? 700 : undefined
    }}>
      <span style={{ color: warn ? 'var(--warn)' : 'var(--muted)' }}>{l}:</span>
      <span style={{ fontWeight: 600, color: warn ? 'var(--warn)' : 'var(--text)' }}>{v}</span>
    </div>
  );
}
