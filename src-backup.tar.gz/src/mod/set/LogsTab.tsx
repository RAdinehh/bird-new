import { useState, useEffect } from 'react';
import { getLogs, clearLogs, exportLogs, logCount, type LogEntry } from '../../cor/logger/logger';
import { Btn, BtnRow, Empty, Modal } from '../../shr/components/ui';
import ExpandableCard from '../../shr/components/ExpandableCard';
import { toFa } from '../../shr/utils/fa';

export default function LogsTab() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showClear, setShowClear] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const refresh = () => setLogs(getLogs());

  useEffect(() => {
    refresh();
  }, []);

  const handleClear = () => {
    clearLogs();
    setShowClear(false);
    refresh();
  };

  const handleExport = () => {
    const json = exportLogs();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'PM-ErrorLogs-' + Date.now() + '.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(exportLogs());
      alert('✓ در کلیپ‌بورد کپی شد');
    } catch {
      alert('✕ خطا در کپی');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
      {/* آمار */}
      <div style={{
        background: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--r-lg)',
        padding: '12px 14px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <div>
          <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)' }}>تعداد خطاهای ثبت‌شده</div>
          <div style={{ fontSize: 'var(--fs-2xl)', fontWeight: 700, color: logs.length > 0 ? 'var(--danger)' : 'var(--accent)', marginTop: 4 }}>
            {toFa(logs.length)}
          </div>
        </div>
        <div style={{ fontSize: 44 }}>{logs.length > 0 ? '⚠' : '✓'}</div>
      </div>

      {/* دکمه‌ها */}
      {logs.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          <Btn size="sm" onClick={handleExport}>📥 خروجی JSON</Btn>
          <Btn size="sm" onClick={handleCopy}>📋 کپی همه</Btn>
        </div>
      ) : null}

      {/* پیام خالی */}
      {logs.length === 0 ? (
        <Empty
          icon={<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
            <path d="M20 6 9 17l-5-5" />
          </svg>}
          title="هیچ خطایی ثبت نشده"
          desc="تا این لحظه، نرم‌افزار بدون خطا کار کرده است. هر خطایی که رخ دهد، این‌جا نمایش داده می‌شود."
        />
      ) : (
        <>
          {/* لیست خطاها */}
          {logs.map((log, i) => {
            const isOpen = expandedId === log.id;
            const time = new Date(log.time);
            const timeStr = toFa(time.toLocaleString('fa-IR'));

            return (
              <ExpandableCard
                key={log.id}
                accent="warn"
                index={toFa(i + 1)}
                iconEmoji="⚠"
                title={log.message.slice(0, 60) + (log.message.length > 60 ? '...' : '')}
                subtitle={timeStr}
                isOpen={isOpen}
                onToggle={() => setExpandedId(isOpen ? null : log.id)}
                summary={<>
                  <span style={{ color: 'var(--warn)', fontWeight: 700 }}>{log.type}</span>
                </>}
              >
                <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)', fontWeight: 700, letterSpacing: '.3px' }}>⏰ زمان</div>
                <div style={{ fontSize: 'var(--fs-sm)', padding: '6px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)' }}>
                  {timeStr}
                </div>

                <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)', fontWeight: 700, letterSpacing: '.3px', marginTop: 4 }}>📋 نوع</div>
                <div style={{ fontSize: 'var(--fs-sm)', padding: '6px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)' }}>
                  {log.type}
                </div>

                <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)', fontWeight: 700, letterSpacing: '.3px', marginTop: 4 }}>💬 پیام</div>
                <div style={{ fontSize: 'var(--fs-sm)', padding: '8px 10px', background: 'var(--danger-soft)', color: 'var(--danger)', borderRadius: 'var(--r-sm)', lineHeight: 1.7, wordBreak: 'break-word' }}>
                  {log.message}
                </div>

                {log.componentStack ? (
                  <>
                    <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)', fontWeight: 700, letterSpacing: '.3px', marginTop: 4 }}>🌳 Stack کامپوننت</div>
                    <div style={{
                      fontSize: 10,
                      fontFamily: 'monospace',
                      padding: '8px 10px',
                      background: 'var(--input-bg)',
                      borderRadius: 'var(--r-sm)',
                      color: 'var(--muted)',
                      maxHeight: 150,
                      overflowY: 'auto',
                      direction: 'ltr',
                      textAlign: 'left',
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word'
                    }}>
                      {log.componentStack.slice(0, 800)}
                    </div>
                  </>
                ) : null}

                {log.url ? (
                  <>
                    <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--muted)', fontWeight: 700, letterSpacing: '.3px', marginTop: 4 }}>🔗 URL</div>
                    <div style={{ fontSize: 'var(--fs-xs)', padding: '6px 10px', background: 'var(--input-bg)', borderRadius: 'var(--r-sm)', direction: 'ltr', textAlign: 'left', wordBreak: 'break-all' }}>
                      {log.url}
                    </div>
                  </>
                ) : null}
              </ExpandableCard>
            );
          })}

          {/* پاک کردن همه */}
          <Btn full variant="danger" onClick={() => setShowClear(true)}>
            🗑 پاک کردن همه
          </Btn>
        </>
      )}

      {/* مودال پاک‌سازی */}
      <Modal
        open={showClear}
        onClose={() => setShowClear(false)}
        title="پاک کردن لاگ‌ها"
        footer={<BtnRow><Btn variant="danger" onClick={handleClear}>پاک کن</Btn><Btn onClick={() => setShowClear(false)}>لغو</Btn></BtnRow>}
      >
        <div style={{ textAlign: 'center', fontSize: 'var(--fs-md)', lineHeight: 1.9 }}>
          همه‌ی {toFa(logs.length)} خطای ثبت‌شده پاک شوند؟
        </div>
      </Modal>
    </div>
  );
}
